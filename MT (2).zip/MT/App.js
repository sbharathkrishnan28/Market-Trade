import { Navbar } from "./components/Navbar.js";
import { DashboardCard } from "./components/DashboardCard.js";
import { StockChart } from "./components/StockChart.js";
import { MarketingStats } from "./components/MarketingStats.js";
import { ChatAssistant } from "./components/ChatAssistant.js";

export function App() {
  const app = document.createElement("div");
  const header = Navbar();

  const main = document.createElement("main");
  main.className = "grid grid-cols-1 md:grid-cols-2 gap-6 p-6";

  const clock = document.createElement("p");
  clock.className = "text-right text-xs text-gray-500 col-span-2";
  setInterval(() => {
    const now = new Date();
    clock.innerText = `🕒 ${now.toLocaleString()}`;
  }, 1000);

  main.appendChild(clock);
  main.appendChild(DashboardCard("📉 Stock Trends", StockChart().outerHTML));
  main.appendChild(DashboardCard("📈 Marketing KPIs", MarketingStats().outerHTML));
  main.appendChild(DashboardCard("🤖 AI Assistant", ChatAssistant().outerHTML));

  app.appendChild(header);
  app.appendChild(main);
  return app;
}
