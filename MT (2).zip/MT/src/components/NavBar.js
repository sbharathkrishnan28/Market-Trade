export function Navbar() {
  const nav = document.createElement("nav");
  nav.className = "bg-blue-800 text-white p-4 flex justify-between items-center shadow";

  nav.innerHTML = `
    <h1 class="text-2xl font-bold">📊 MarkTrade</h1>
    <button id="themeToggle" class="text-sm bg-white text-blue-800 px-2 py-1 rounded">Toggle Theme</button>
  `;

  nav.querySelector("#themeToggle").onclick = () => {
    document.body.classList.toggle("dark");
  };

  return nav;
}
