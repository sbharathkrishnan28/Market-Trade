export function LoginPage(onLoginSuccess) {
  const container = document.createElement("div");
  container.className = "flex flex-col items-center justify-center h-screen bg-gray-100";
  container.innerHTML = `
    <div class="bg-white p-8 rounded shadow w-80">
      <h2 class="text-xl font-bold mb-4 text-center">Login</h2>
      <input id="email" type="email" placeholder="Email" class="border p-2 mb-2 w-full" />
      <input id="password" type="password" placeholder="Password" class="border p-2 mb-4 w-full" />
      <button id="loginBtn" class="bg-blue-600 text-white px-4 py-2 w-full">Login</button>
      <p class="text-sm mt-4 text-center">Don't have an account? <a href="#" id="gotoSignup" class="text-blue-600">Sign up</a></p>
    </div>
  `;

  container.querySelector("#loginBtn").onclick = () => {
    const email = container.querySelector("#email").value;
    const password = container.querySelector("#password").value;
    if (email && password) {
      localStorage.setItem("user", email);
      onLoginSuccess();
    } else {
      alert("Please fill in all fields");
    }
  };

  return container;
}
