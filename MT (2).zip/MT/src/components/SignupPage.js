export function SignupPage(onSignupSuccess) {
  const container = document.createElement("div");
  container.className = "flex flex-col items-center justify-center h-screen bg-gray-100";
  container.innerHTML = `
    <div class="bg-white p-8 rounded shadow w-80">
      <h2 class="text-xl font-bold mb-4 text-center">Sign Up</h2>
      <input id="newEmail" type="email" placeholder="Email" class="border p-2 mb-2 w-full" />
      <input id="newPassword" type="password" placeholder="Password" class="border p-2 mb-4 w-full" />
      <button id="signupBtn" class="bg-green-600 text-white px-4 py-2 w-full">Create Account</button>
      <p class="text-sm mt-4 text-center">Already have an account? <a href="#" id="gotoLogin" class="text-blue-600">Login</a></p>
    </div>
  `;

  container.querySelector("#signupBtn").onclick = () => {
    const email = container.querySelector("#newEmail").value;
    const password = container.querySelector("#newPassword").value;
    if (email && password) {
      localStorage.setItem("user", email);
      onSignupSuccess();
    } else {
      alert("Please fill in all fields");
    }
  };

  return container;
}
