export function DashboardCard(title, content) {
  const card = document.createElement("div");
  card.className = "bg-white shadow-md rounded-lg p-6 m-2";
  card.innerHTML = `<h2 class="text-lg font-semibold mb-4">${title}</h2><div>${content}</div>`;
  return card;
}
