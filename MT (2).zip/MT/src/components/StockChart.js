export function StockChart() {
  const div = document.createElement("div");
  div.className = "text-gray-500 h-40 flex items-center justify-center";
  div.innerText = "📈 MACD/RSI Live Stock Chart (Simulated)";
  return div;
}
