export function MarketingStats() {
  const wrapper = document.createElement("div");
  wrapper.className = "space-y-2";

  const ul = document.createElement("ul");
  ul.className = "list-disc list-inside text-gray-700 text-sm";
  ul.innerHTML = `
    <li>CTR: 4.6%</li>
    <li id="roi">ROI: 162%</li>
    <li>Top Channel: Instagram Reels</li>
    <li>Suggestion: Improve CTA</li>
  `;

  setInterval(() => {
    const roi = (150 + Math.random() * 30).toFixed(2);
    ul.querySelector("#roi").innerText = `ROI: ${roi}%`;
  }, 3000);

  const btn = document.createElement("button");
  btn.innerText = "📁 Export JSON";
  btn.className = "text-xs mt-2 px-2 py-1 border rounded text-blue-700";
  btn.onclick = () => {
    const data = {
      ctr: "4.6%",
      roi: ul.querySelector("#roi").innerText,
      channel: "Instagram Reels"
    };
    const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "marketing-stats.json";
    link.click();
  };

  wrapper.appendChild(ul);
  wrapper.appendChild(btn);
  return wrapper;
}
