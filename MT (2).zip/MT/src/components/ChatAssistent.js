export function ChatAssistant() {
  const container = document.createElement("div");
  container.className = "text-sm text-gray-700";
  container.innerHTML = `
    <p>🧠 Ask: "Which ad worked best this week?"</p>
    <p class="italic">Voice/Text Q&A assistant (offline-enabled)</p>
  `;
  return container;
}
