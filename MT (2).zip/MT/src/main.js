// main.js

// Import all components
import { App } from './App.js';
import { LoginPage } from './components/LoginPage.js';
import { SignupPage } from './components/SignupPage.js';

// Ensure the DOM is fully loaded before executing
document.addEventListener("DOMContentLoaded", () => {
  const root = document.getElementById("root");

  // Load Dashboard Page
  function showApp() {
    root.innerHTML = "";
    const app = App();

    // Create logout button
    const logoutBtn = document.createElement("button");
    logoutBtn.innerText = "Logout";
    logoutBtn.className = "fixed top-4 right-4 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded shadow";
    logoutBtn.onclick = () => {
      localStorage.removeItem("user");
      showLogin();
    };

    root.appendChild(logoutBtn);
    root.appendChild(app);
  }

  // Load Login Page
  function showLogin() {
    root.innerHTML = "";
    const login = LoginPage(showApp);
    
    const goToSignupBtn = login.querySelector("#gotoSignup");
    if (goToSignupBtn) {
      goToSignupBtn.onclick = showSignup;
    }

    root.appendChild(login);
  }

  // Load Signup Page
  function showSignup() {
    root.innerHTML = "";
    const signup = SignupPage(showApp);

    const goToLoginBtn = signup.querySelector("#gotoLogin");
    if (goToLoginBtn) {
      goToLoginBtn.onclick = showLogin;
    }

    root.appendChild(signup);
  }

  // Show either app or login based on login status
  const user = localStorage.getItem("user");
  if (user) {
    showApp();
  } else {
    showLogin();
  }
});
